﻿
/****************************************************************************************************
**                                    SAKARYA ÜNİVERSİTESİ                                         **
**                            BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ                            **
**                                  BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ                                 **
**                                 NESNEYE DAYALI PROGRAMLAMA DERSİ                                ** 
**                                      2021-2022 BAHAR DÖNEMİ                                     **
**                                                                                                 **
**                            ÖDEV NUMARASI: 2                                                     **
**                           ÖĞRENCİ ADI: HAVVA NUR KAYMAKÇI                                       ** 
**                           ÖĞRENCİ NUMARASI:G211210033                                           **   
**                           DERSİN ALINDIĞI GRUP: 2.ÖĞRETİM B GRUBU                               **
*****************************************************************************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace odevDinamik
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Button btnHesapla = new Button();
        TextBox txtSayi = new TextBox();
        Label lblTutar = new Label();
        Label lblYazi = new Label();
        Label lblHata = new Label();
        private void Form1_Load(object sender, EventArgs e)
        {

            txtSayi.Location = new Point(250, 32);
            txtSayi.Width = 60;
            txtSayi.Height = 55;
            txtSayi.AutoSize = true;
            this.Controls.Add(txtSayi);

            lblTutar.BorderStyle = BorderStyle.Fixed3D;
            lblTutar.Location = new Point(95, 35);
            lblTutar.Text = ("Fatura tutarını giriniz:");
            lblTutar.Width = 180;
            lblTutar.Height = 50;
            lblTutar.AutoSize = true;
            this.Controls.Add(lblTutar);

            lblYazi.BorderStyle = BorderStyle.Fixed3D;
            lblYazi.Location = new Point(250, 70);
            lblYazi.Width = 125;
            lblYazi.Height = 50;
            lblYazi.AutoSize = true;
            this.Controls.Add(lblYazi);

            btnHesapla.Text = ("HESAPLA");
            btnHesapla.Location = new Point(120, 65);
            btnHesapla.Width = 65;
            btnHesapla.Height = 30;
            btnHesapla.BackColor = Color.LightGray;
            btnHesapla.AutoSize = true;
            this.Controls.Add(btnHesapla);
            btnHesapla.Click += btnTikla_Click;
            btnHesapla.Click += new EventHandler(btnTikla_Click);
        }

        static bool sayiyioku( double sayi , out string gecici)     
        {
            string[] strbir = { "Bir", "İki", "Üç", "Dört", "Beş", "Altı", "Yedi", "Sekiz", "Dokuz", "On", "On bir", "On iki", "On üç", "On dört", "On beş", "On altı", "On yedi", "On sekiz", "On dokuz" };

            string[] stron = { "On", "Yirmi", "Otuz", "Kırk", "Elli", "Altmış", "Yetmiş", "Seksen", "Doksan", "Yüz" };
           
            string sonuc = "";
            gecici = "";
            int birler, onlar, yuzler;

            if (sayi > 1000)
                return false;

            yuzler = (int)sayi / 100;
            sayi = sayi - yuzler * 100;

            if (sayi < 20)
            {
                onlar = 0;
                birler = (int)sayi;
            }
            else
            {
                onlar = (int)sayi / 10;
                sayi = sayi - onlar * 10;
                birler = (int)sayi;
            }
            sonuc = "";

            if (yuzler > 0)
            {
                if (yuzler == 1)
                    sonuc += "";
                else
                    sonuc += strbir [(yuzler - 1)];
                sonuc += " Yüz ";
            }
            if (onlar > 0)
            {
                sonuc += stron[onlar - 1];
                sonuc += " ";
            }
            if (birler > 0)
            {
                sonuc += strbir[birler - 1];
                sonuc += " ";
            }
            gecici = sonuc;
            return true;
        }

        static bool yaziyacevir(int sayi, out string sonuc)
        {
            string gecicisonuc = "";
            int binler;
            int gecici;
            sonuc = "";
            if (sayi < 0 || sayi > 99999)
            {
                System.Console.WriteLine(sayi + " Desteklenmeyen Aralık");
                return false;
            }

            if (sayi == 0)
            {
                System.Console.WriteLine(sayi + " tSıfır");
                return false;
            }

            if (sayi < 1000)
            {
                sayiyioku(sayi, out gecicisonuc);
                sonuc += gecicisonuc;
            }
            else
            {
                binler = sayi / 1000;
                gecici = sayi - binler * 1000;
                if (binler == 1)
                    sonuc += "";
                else
                    sayiyioku(binler, out gecicisonuc);
                sonuc += gecicisonuc;
                sonuc += "Bin ";
                sayiyioku(gecici, out gecicisonuc);
                sonuc += gecicisonuc;

            }
            return true;
        }
        private void btnTikla_Click(object sender, EventArgs e)
        {
            lblYazi.Text = "";
            int sayi;
            sayi = Convert.ToInt32(txtSayi.Text);

            string sonuc;
            yaziyacevir(sayi, out sonuc);

                lblYazi.Text = sonuc + ("TL");

        }
    }
}
