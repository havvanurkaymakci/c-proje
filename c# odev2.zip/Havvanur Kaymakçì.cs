﻿using System;

namespace Havvanur_Kaymakçı
{
    public static class Password
    {
        public static string sifre;
        public static int rakamSayisi = 0;
        public static int ozelKarakterSayisi = 0;
        public static int buyukHarfSayisi = 0;
        public static int kucukHarfSayisi = 0;
        public static int puan = 0;
        public static int puan1 = 0;

        public static void RakamSayisiniBul()
        {
            char[] toplamkarakter = sifre.ToCharArray();
            foreach (var karakter in toplamkarakter)
            {
                if (char.IsDigit(karakter))
                    rakamSayisi++;
            }
            Console.WriteLine("Rakam sayısı: " + rakamSayisi);
            if (rakamSayisi == 0)
            {
                Console.WriteLine("Şifrenizde en az bir tane rakam bulunmalı.");
            }
            else if (rakamSayisi == 1)
            {
                puan += 10;
            }
            else if (rakamSayisi >= 2)
            {
                puan += 20;
            }

        }
        public static void OzelkarakterSayisiniBul()
        {
            char[] toplamkarakter = sifre.ToCharArray();
            foreach (var karakter in toplamkarakter)
            {
                if (char.IsSymbol(karakter) || char.IsPunctuation(karakter))
                    ozelKarakterSayisi++;
            }
            puan1 = ozelKarakterSayisi * 10;
            Console.WriteLine("Özel karakter sayısı:" + ozelKarakterSayisi);
            if (Password.ozelKarakterSayisi == 0)
            {
                Console.WriteLine("Şifrenizde en az bir özel tane karakter bulunmalı.");
            }
        }
        public static void BuyukHarfBul()
        {
            char[] buyukHarfler = { 'A', 'B', 'C', 'Ç', 'D', 'E', 'F', 'G', 'H', 'I', 'İ', 'J', 'K', 'L', 'M', 'N', 'O', 'Ö', 'P', 'R', 'S', 'Ş', 'T', 'U', 'Ü', 'V', 'Y', 'Z' };
            foreach (var karakter in sifre)
                foreach (char buyukHarf in buyukHarfler)
                    if (karakter == buyukHarf)
                        buyukHarfSayisi++;
            Console.WriteLine("Büyük harf sayısı: " + buyukHarfSayisi);

            if (buyukHarfSayisi == 0)
            {
                Console.WriteLine("Şifrenizde en az bir tane büyük harf bulunmalı.");
            }
            else if (buyukHarfSayisi == 1)
            {
                puan += 10;
            }
            else if (buyukHarfSayisi >= 2)
            {
                puan += 20;
            }
        }

        public static void KucukHarfBul()
        {
            char[] kucukHarfler = { 'a', 'b', 'c', 'ç', 'd', 'e', 'f', 'g', 'h', 'ı', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'ö', 'p', 'r', 's', 'ş', 't', 'u', 'ü', 'v', 'y', 'z' };
            foreach (var karakter in sifre)
                foreach (char kucukHarf in kucukHarfler)
                    if (karakter == kucukHarf)
                        kucukHarfSayisi++;
            Console.WriteLine("Küçük harf sayısı: " + kucukHarfSayisi);

            if (kucukHarfSayisi == 0)
            {
                Console.WriteLine("Şifrenizde en az bir tane küçük harf bulunmalı.");
            }
            else if (kucukHarfSayisi == 1)
            {
                puan += 10;
            }
            else if (kucukHarfSayisi >= 2)
            {
                puan += 20;
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Şifrenizi giriniz:");
            Password.sifre = Console.ReadLine();
            if (Password.sifre.Length >= 9)
            {
                Password.RakamSayisiniBul();
                Password.OzelkarakterSayisiniBul();
                Password.BuyukHarfBul();
                Password.KucukHarfBul();

                int toplamPuan = Password.puan + Password.puan1;

                if (Password.sifre.Length == 9)
                {
                    toplamPuan += 10;
                }
                Console.WriteLine("toplam puan:" + toplamPuan);

                bool kontrol = true;
                for (int i = 0; i < Password.sifre.ToCharArray().Length; i++)
                {
                    if (Password.sifre.ToCharArray()[i].ToString() == " ")
                    {
                        kontrol = false;
                    }
                }

                if (toplamPuan < 70)
                {
                    Console.WriteLine("toplam puan:" + toplamPuan);
                    Console.WriteLine("Şifreniz yeterince güçlü değil.");
                    System.Diagnostics.Process.Start(System.AppDomain.CurrentDomain.FriendlyName);

                    if (kontrol == false)
                    {
                        Console.WriteLine("Şifrenizde boşluk bulunmamalı.");
                        System.Diagnostics.Process.Start(System.AppDomain.CurrentDomain.FriendlyName);
                    }
                }

                else if (toplamPuan >= 70)
                {
                    if (kontrol == false)
                    {
                        Console.WriteLine("Şifrenizde boşluk bulunmamalı.");
                        System.Diagnostics.Process.Start(System.AppDomain.CurrentDomain.FriendlyName);
                    }

                    else if (Password.ozelKarakterSayisi == 0 || Password.rakamSayisi == 0 || Password.kucukHarfSayisi == 0 || Password.buyukHarfSayisi == 0)
                    {
                        Console.WriteLine("Şifrenizde en az bir tsne rakam,özel karakter,büyük vya küçük harf bulunmalı.");
                        System.Diagnostics.Process.Start(System.AppDomain.CurrentDomain.FriendlyName);
                    }

                    else if (toplamPuan < 90)
                    {
                        Console.WriteLine("toplam puan:" + toplamPuan);
                        Console.WriteLine("Şifreniz kabul edilmiştir.");
                    }

                    else if (toplamPuan >= 90)
                    {
                        Console.WriteLine("toplam puan:" + toplamPuan);
                        Console.WriteLine("Şifreniz kabul edilmiştir.");
                        Console.WriteLine("Şifre: GÜÇLÜ");
                    }
                }
            }

            else
            {
                Console.Clear();
                Console.WriteLine("Şifreniz en az 9 karakter olmalıdır.");
                System.Diagnostics.Process.Start(System.AppDomain.CurrentDomain.FriendlyName);
            }
        }    
    }
}
