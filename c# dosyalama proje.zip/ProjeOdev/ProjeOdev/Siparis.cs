﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProjeOdev
{
    public partial class Siparis : Form
    {
        public Siparis()
        {
            InitializeComponent();
        }

        private void Siparis_Load(object sender, EventArgs e)
        {

        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            FileStream TedarikciDosyasi;
            StreamWriter stedarik;
            TedarikciDosyasi = new FileStream(@"c:\Proje\Tedarikci.txt", FileMode.Append, FileAccess.Write);
            stedarik = new StreamWriter(TedarikciDosyasi);
            stedarik.Write(txtadi.Text + "    ");
            stedarik.WriteLine(txtadres.Text + "    ");

            string kategori = "Kadın";
            int miktar = 0;
            FileStream siparisDosyasi;
            StreamWriter strsiparis;
            siparisDosyasi = new FileStream(@"c:\Proje\Siparis.txt", FileMode.Append, FileAccess.Write);
            strsiparis = new StreamWriter(siparisDosyasi);

            if (rbKadin.Checked == true)
            {
                strsiparis.Write(kategori = "Kadın");
            }
            if (rbErkek.Checked == true)
            {
                strsiparis.Write(kategori = "Erkek");
            }
            if (rbKadin.Checked == true)
            {
                strsiparis.Write(kategori = "Çocuk");
            }

            strsiparis.Write(txttarih.Text + "    ");
            strsiparis.Write(txtcins.Text + "    ");
            strsiparis.WriteLine(txtfiyat.Text + "    ");
            cbmiktar.Items.Add(miktar);

            stedarik.Close();
            TedarikciDosyasi.Close();

            strsiparis.Close();
            siparisDosyasi.Close();

            FileStream stokDosyasi;
            StreamWriter strstok;
            stokDosyasi = new FileStream(@"c:\Proje\Stok.txt", FileMode.Append, FileAccess.Write);
            strstok = new StreamWriter(stokDosyasi);
            strstok.Write(txtcins.Text + "    ");
            cbmiktar.Items.Add(miktar);

            if (rbKadin.Checked == true)
            {
                strstok.Write(kategori = "Kadın");
            }
            if (rbErkek.Checked == true)
            {
                strstok.Write(kategori = "Erkek");
            }
            if (rbKadin.Checked == true)
            {
                strstok.Write(kategori = "Çocuk");
            }
            strstok.Close();
            stokDosyasi.Close();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            Form1 geri1 = new Form1();
            geri1.Show();
            this.Hide();
        }
    }
}
