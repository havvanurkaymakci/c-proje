﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProjeOdev
{
    public partial class Gider : Form
    {
        public Gider()
        {
            InitializeComponent();
        }

        private void btnguncelle_Click(object sender, EventArgs e)
        {
            FileStream Giderdosyasi;
            StreamWriter sGider;
            Giderdosyasi = new FileStream(@"c:\Proje\Gider.txt", FileMode.Append, FileAccess.Write);
            sGider = new StreamWriter(Giderdosyasi);
            sGider.Write(txtAy.Text + "    ");
            sGider.Write(txtKira.Text + "    ");
            sGider.Write(txtelektrik.Text + "    ");
            sGider.Write(txtsu.Text + "    ");
            sGider.Write(txtdogalgaz.Text + "    ");
            sGider.WriteLine(txtmaas.Text + "    ");
            sGider.Close();
            Giderdosyasi.Close();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {

            Form1 giris = new Form1();
            giris.Show();
            this.Hide();
        }

        private void btngider_Click(object sender, EventArgs e)
        {
            StreamReader sGider = File.OpenText(@"c:\Proje\Gider.txt");
            string metin;
            while ((metin = sGider.ReadLine()) != null)
            {
                listGider.Items.Add(metin);
            }
            sGider.Close();
        }
    }
}
