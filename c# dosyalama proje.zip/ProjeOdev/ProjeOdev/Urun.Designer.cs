﻿
namespace ProjeOdev
{
    partial class Urun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtmiktar = new System.Windows.Forms.TextBox();
            this.lblurunmiktar = new System.Windows.Forms.Label();
            this.txturunfiyat = new System.Windows.Forms.TextBox();
            this.lblurunfiyat = new System.Windows.Forms.Label();
            this.txturunkodu = new System.Windows.Forms.TextBox();
            this.txturunadı = new System.Windows.Forms.TextBox();
            this.rbtncocuk = new System.Windows.Forms.RadioButton();
            this.rbtnkadin = new System.Windows.Forms.RadioButton();
            this.rbtnerkek = new System.Windows.Forms.RadioButton();
            this.lblurunkodu = new System.Windows.Forms.Label();
            this.lblUrunadi = new System.Windows.Forms.Label();
            this.lblkategori = new System.Windows.Forms.Label();
            this.btnal = new System.Windows.Forms.Button();
            this.btnara = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtgirilenkod = new System.Windows.Forms.TextBox();
            this.cbmiktar = new System.Windows.Forms.ComboBox();
            this.Rafliste = new System.Windows.Forms.ListBox();
            this.btnraf = new System.Windows.Forms.Button();
            this.btndepo = new System.Windows.Forms.Button();
            this.Depoliste = new System.Windows.Forms.ListBox();
            this.btnrafekle = new System.Windows.Forms.Button();
            this.btngeri = new System.Windows.Forms.Button();
            this.btnurunekle = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtmiktar);
            this.groupBox1.Controls.Add(this.lblurunmiktar);
            this.groupBox1.Controls.Add(this.txturunfiyat);
            this.groupBox1.Controls.Add(this.lblurunfiyat);
            this.groupBox1.Controls.Add(this.txturunkodu);
            this.groupBox1.Controls.Add(this.txturunadı);
            this.groupBox1.Controls.Add(this.rbtncocuk);
            this.groupBox1.Controls.Add(this.rbtnkadin);
            this.groupBox1.Controls.Add(this.rbtnerkek);
            this.groupBox1.Controls.Add(this.lblurunkodu);
            this.groupBox1.Controls.Add(this.lblUrunadi);
            this.groupBox1.Controls.Add(this.lblkategori);
            this.groupBox1.Location = new System.Drawing.Point(36, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 230);
            this.groupBox1.TabIndex = 71;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ürün ekleme";
            // 
            // txtmiktar
            // 
            this.txtmiktar.Location = new System.Drawing.Point(142, 159);
            this.txtmiktar.Name = "txtmiktar";
            this.txtmiktar.Size = new System.Drawing.Size(100, 23);
            this.txtmiktar.TabIndex = 60;
            // 
            // lblurunmiktar
            // 
            this.lblurunmiktar.AutoSize = true;
            this.lblurunmiktar.BackColor = System.Drawing.Color.PeachPuff;
            this.lblurunmiktar.Location = new System.Drawing.Point(25, 159);
            this.lblurunmiktar.Name = "lblurunmiktar";
            this.lblurunmiktar.Size = new System.Drawing.Size(76, 15);
            this.lblurunmiktar.TabIndex = 59;
            this.lblurunmiktar.Text = "Ürün Miktarı:";
            // 
            // txturunfiyat
            // 
            this.txturunfiyat.Location = new System.Drawing.Point(142, 118);
            this.txturunfiyat.Name = "txturunfiyat";
            this.txturunfiyat.Size = new System.Drawing.Size(100, 23);
            this.txturunfiyat.TabIndex = 58;
            // 
            // lblurunfiyat
            // 
            this.lblurunfiyat.AutoSize = true;
            this.lblurunfiyat.BackColor = System.Drawing.Color.PeachPuff;
            this.lblurunfiyat.Location = new System.Drawing.Point(25, 122);
            this.lblurunfiyat.Name = "lblurunfiyat";
            this.lblurunfiyat.Size = new System.Drawing.Size(65, 15);
            this.lblurunfiyat.TabIndex = 57;
            this.lblurunfiyat.Text = "Ürün fiyatı:";
            // 
            // txturunkodu
            // 
            this.txturunkodu.Location = new System.Drawing.Point(142, 47);
            this.txturunkodu.Name = "txturunkodu";
            this.txturunkodu.Size = new System.Drawing.Size(100, 23);
            this.txturunkodu.TabIndex = 56;
            // 
            // txturunadı
            // 
            this.txturunadı.Location = new System.Drawing.Point(142, 84);
            this.txturunadı.Name = "txturunadı";
            this.txturunadı.Size = new System.Drawing.Size(100, 23);
            this.txturunadı.TabIndex = 55;
            // 
            // rbtncocuk
            // 
            this.rbtncocuk.AutoSize = true;
            this.rbtncocuk.Location = new System.Drawing.Point(287, 195);
            this.rbtncocuk.Name = "rbtncocuk";
            this.rbtncocuk.Size = new System.Drawing.Size(59, 19);
            this.rbtncocuk.TabIndex = 54;
            this.rbtncocuk.TabStop = true;
            this.rbtncocuk.Text = "Çocuk";
            this.rbtncocuk.UseVisualStyleBackColor = true;
            // 
            // rbtnkadin
            // 
            this.rbtnkadin.AutoSize = true;
            this.rbtnkadin.Location = new System.Drawing.Point(142, 195);
            this.rbtnkadin.Name = "rbtnkadin";
            this.rbtnkadin.Size = new System.Drawing.Size(55, 19);
            this.rbtnkadin.TabIndex = 53;
            this.rbtnkadin.TabStop = true;
            this.rbtnkadin.Text = "Kadın";
            this.rbtnkadin.UseVisualStyleBackColor = true;
            // 
            // rbtnerkek
            // 
            this.rbtnerkek.AutoSize = true;
            this.rbtnerkek.Location = new System.Drawing.Point(215, 195);
            this.rbtnerkek.Name = "rbtnerkek";
            this.rbtnerkek.Size = new System.Drawing.Size(53, 19);
            this.rbtnerkek.TabIndex = 52;
            this.rbtnerkek.TabStop = true;
            this.rbtnerkek.Text = "Erkek";
            this.rbtnerkek.UseVisualStyleBackColor = true;
            // 
            // lblurunkodu
            // 
            this.lblurunkodu.AutoSize = true;
            this.lblurunkodu.BackColor = System.Drawing.Color.PeachPuff;
            this.lblurunkodu.Location = new System.Drawing.Point(25, 50);
            this.lblurunkodu.Name = "lblurunkodu";
            this.lblurunkodu.Size = new System.Drawing.Size(66, 15);
            this.lblurunkodu.TabIndex = 51;
            this.lblurunkodu.Text = "Ürün kodu:";
            // 
            // lblUrunadi
            // 
            this.lblUrunadi.AutoSize = true;
            this.lblUrunadi.BackColor = System.Drawing.Color.PeachPuff;
            this.lblUrunadi.Location = new System.Drawing.Point(25, 87);
            this.lblUrunadi.Name = "lblUrunadi";
            this.lblUrunadi.Size = new System.Drawing.Size(108, 15);
            this.lblUrunadi.TabIndex = 50;
            this.lblUrunadi.Text = "Ürün cinsini giriniz:\r\n";
            // 
            // lblkategori
            // 
            this.lblkategori.AutoSize = true;
            this.lblkategori.BackColor = System.Drawing.Color.PeachPuff;
            this.lblkategori.Location = new System.Drawing.Point(25, 195);
            this.lblkategori.Name = "lblkategori";
            this.lblkategori.Size = new System.Drawing.Size(93, 15);
            this.lblkategori.TabIndex = 49;
            this.lblkategori.Text = "Kategori Seçiniz:";
            // 
            // btnal
            // 
            this.btnal.BackColor = System.Drawing.Color.GhostWhite;
            this.btnal.Location = new System.Drawing.Point(679, 129);
            this.btnal.Name = "btnal";
            this.btnal.Size = new System.Drawing.Size(69, 23);
            this.btnal.TabIndex = 70;
            this.btnal.Text = "Satın al";
            this.btnal.UseVisualStyleBackColor = false;
            this.btnal.Click += new System.EventHandler(this.btnal_Click);
            // 
            // btnara
            // 
            this.btnara.BackColor = System.Drawing.Color.GhostWhite;
            this.btnara.Location = new System.Drawing.Point(774, 73);
            this.btnara.Name = "btnara";
            this.btnara.Size = new System.Drawing.Size(69, 23);
            this.btnara.TabIndex = 69;
            this.btnara.Text = "Ürün ara";
            this.btnara.UseVisualStyleBackColor = false;
            this.btnara.Click += new System.EventHandler(this.btnara_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PeachPuff;
            this.label1.Location = new System.Drawing.Point(555, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 15);
            this.label1.TabIndex = 68;
            this.label1.Text = "Ürün kodunu giriniz :";
            // 
            // txtgirilenkod
            // 
            this.txtgirilenkod.Location = new System.Drawing.Point(679, 73);
            this.txtgirilenkod.Name = "txtgirilenkod";
            this.txtgirilenkod.Size = new System.Drawing.Size(69, 23);
            this.txtgirilenkod.TabIndex = 67;
            // 
            // cbmiktar
            // 
            this.cbmiktar.FormattingEnabled = true;
            this.cbmiktar.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbmiktar.Location = new System.Drawing.Point(565, 130);
            this.cbmiktar.Name = "cbmiktar";
            this.cbmiktar.Size = new System.Drawing.Size(99, 23);
            this.cbmiktar.TabIndex = 66;
            this.cbmiktar.Text = "Miktar seçiniz";
            // 
            // Rafliste
            // 
            this.Rafliste.FormattingEnabled = true;
            this.Rafliste.ItemHeight = 15;
            this.Rafliste.Location = new System.Drawing.Point(548, 330);
            this.Rafliste.Name = "Rafliste";
            this.Rafliste.Size = new System.Drawing.Size(368, 94);
            this.Rafliste.TabIndex = 65;
            // 
            // btnraf
            // 
            this.btnraf.BackColor = System.Drawing.Color.LightGreen;
            this.btnraf.Location = new System.Drawing.Point(202, 384);
            this.btnraf.Name = "btnraf";
            this.btnraf.Size = new System.Drawing.Size(94, 55);
            this.btnraf.TabIndex = 64;
            this.btnraf.Text = "Raftaki Ürünleri Listele";
            this.btnraf.UseVisualStyleBackColor = false;
            this.btnraf.Click += new System.EventHandler(this.btnraf_Click);
            // 
            // btndepo
            // 
            this.btndepo.BackColor = System.Drawing.Color.LightGreen;
            this.btndepo.Location = new System.Drawing.Point(73, 384);
            this.btndepo.Name = "btndepo";
            this.btndepo.Size = new System.Drawing.Size(96, 55);
            this.btndepo.TabIndex = 63;
            this.btndepo.Text = "Depodaki Ürünleri Listele";
            this.btndepo.UseVisualStyleBackColor = false;
            this.btndepo.Click += new System.EventHandler(this.btndepo_Click);
            // 
            // Depoliste
            // 
            this.Depoliste.FormattingEnabled = true;
            this.Depoliste.ItemHeight = 15;
            this.Depoliste.Location = new System.Drawing.Point(548, 194);
            this.Depoliste.Name = "Depoliste";
            this.Depoliste.Size = new System.Drawing.Size(368, 94);
            this.Depoliste.TabIndex = 62;
            // 
            // btnrafekle
            // 
            this.btnrafekle.BackColor = System.Drawing.Color.LightGreen;
            this.btnrafekle.Location = new System.Drawing.Point(212, 312);
            this.btnrafekle.Name = "btnrafekle";
            this.btnrafekle.Size = new System.Drawing.Size(75, 41);
            this.btnrafekle.TabIndex = 61;
            this.btnrafekle.Text = "Rafa Ekle";
            this.btnrafekle.UseVisualStyleBackColor = false;
            this.btnrafekle.Click += new System.EventHandler(this.btnrafekle_Click);
            // 
            // btngeri
            // 
            this.btngeri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btngeri.Location = new System.Drawing.Point(342, 400);
            this.btngeri.Name = "btngeri";
            this.btngeri.Size = new System.Drawing.Size(75, 23);
            this.btngeri.TabIndex = 60;
            this.btngeri.Text = "Geri";
            this.btngeri.UseVisualStyleBackColor = false;
            this.btngeri.Click += new System.EventHandler(this.btngeri_Click);
            // 
            // btnurunekle
            // 
            this.btnurunekle.BackColor = System.Drawing.Color.LightGreen;
            this.btnurunekle.Location = new System.Drawing.Point(91, 312);
            this.btnurunekle.Name = "btnurunekle";
            this.btnurunekle.Size = new System.Drawing.Size(75, 41);
            this.btnurunekle.TabIndex = 59;
            this.btnurunekle.Text = "Depoya Ekle";
            this.btnurunekle.UseVisualStyleBackColor = false;
            this.btnurunekle.Click += new System.EventHandler(this.btnurunekle_Click);
            // 
            // Urun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(953, 476);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnal);
            this.Controls.Add(this.btnara);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtgirilenkod);
            this.Controls.Add(this.cbmiktar);
            this.Controls.Add(this.Rafliste);
            this.Controls.Add(this.btnraf);
            this.Controls.Add(this.btndepo);
            this.Controls.Add(this.Depoliste);
            this.Controls.Add(this.btnrafekle);
            this.Controls.Add(this.btngeri);
            this.Controls.Add(this.btnurunekle);
            this.Name = "Urun";
            this.Text = "Urun";
            this.Load += new System.EventHandler(this.Urun_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox txtmiktar;
        private System.Windows.Forms.Label lblurunmiktar;
        public System.Windows.Forms.TextBox txturunfiyat;
        private System.Windows.Forms.Label lblurunfiyat;
        public System.Windows.Forms.TextBox txturunkodu;
        private System.Windows.Forms.TextBox txturunadı;
        private System.Windows.Forms.RadioButton rbtncocuk;
        private System.Windows.Forms.RadioButton rbtnkadin;
        private System.Windows.Forms.RadioButton rbtnerkek;
        private System.Windows.Forms.Label lblurunkodu;
        private System.Windows.Forms.Label lblUrunadi;
        private System.Windows.Forms.Label lblkategori;
        private System.Windows.Forms.Button btnal;
        private System.Windows.Forms.Button btnara;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtgirilenkod;
        private System.Windows.Forms.ComboBox cbmiktar;
        private System.Windows.Forms.ListBox Rafliste;
        private System.Windows.Forms.Button btnraf;
        private System.Windows.Forms.Button btndepo;
        private System.Windows.Forms.ListBox Depoliste;
        private System.Windows.Forms.Button btnrafekle;
        private System.Windows.Forms.Button btngeri;
        private System.Windows.Forms.Button btnurunekle;
    }
}