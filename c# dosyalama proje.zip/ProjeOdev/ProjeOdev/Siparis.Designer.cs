﻿
namespace ProjeOdev
{
    partial class Siparis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtrunkodu = new System.Windows.Forms.TextBox();
            this.lblurunkodu = new System.Windows.Forms.Label();
            this.txtadi = new System.Windows.Forms.TextBox();
            this.lbladi = new System.Windows.Forms.Label();
            this.btnekle = new System.Windows.Forms.Button();
            this.btnGeri = new System.Windows.Forms.Button();
            this.rbKadin = new System.Windows.Forms.RadioButton();
            this.rbErkek = new System.Windows.Forms.RadioButton();
            this.rbCocuk = new System.Windows.Forms.RadioButton();
            this.lblkategori = new System.Windows.Forms.Label();
            this.cbmiktar = new System.Windows.Forms.ComboBox();
            this.txtcins = new System.Windows.Forms.TextBox();
            this.txtfiyat = new System.Windows.Forms.TextBox();
            this.txtadres = new System.Windows.Forms.TextBox();
            this.txttarih = new System.Windows.Forms.TextBox();
            this.lblSprsFiyat = new System.Windows.Forms.Label();
            this.lblSprsmiktar = new System.Windows.Forms.Label();
            this.lblSprsCins = new System.Windows.Forms.Label();
            this.lblsprsTarih = new System.Windows.Forms.Label();
            this.lblSprsAdres = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ProjeOdev.Properties.Resources.Online_Shopping_An_Alternative_to_Shopping_in_the_Market;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(510, 69);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(323, 176);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 64;
            this.pictureBox1.TabStop = false;
            // 
            // txtrunkodu
            // 
            this.txtrunkodu.Location = new System.Drawing.Point(178, 237);
            this.txtrunkodu.Name = "txtrunkodu";
            this.txtrunkodu.Size = new System.Drawing.Size(100, 23);
            this.txtrunkodu.TabIndex = 63;
            // 
            // lblurunkodu
            // 
            this.lblurunkodu.AutoSize = true;
            this.lblurunkodu.BackColor = System.Drawing.Color.PeachPuff;
            this.lblurunkodu.Location = new System.Drawing.Point(65, 245);
            this.lblurunkodu.Name = "lblurunkodu";
            this.lblurunkodu.Size = new System.Drawing.Size(67, 15);
            this.lblurunkodu.TabIndex = 62;
            this.lblurunkodu.Text = "Ürün Kodu:";
            // 
            // txtadi
            // 
            this.txtadi.Location = new System.Drawing.Point(178, 69);
            this.txtadi.Name = "txtadi";
            this.txtadi.Size = new System.Drawing.Size(100, 23);
            this.txtadi.TabIndex = 61;
            // 
            // lbladi
            // 
            this.lbladi.AutoSize = true;
            this.lbladi.BackColor = System.Drawing.Color.PeachPuff;
            this.lbladi.Location = new System.Drawing.Point(65, 72);
            this.lbladi.Name = "lbladi";
            this.lbladi.Size = new System.Drawing.Size(89, 15);
            this.lbladi.TabIndex = 60;
            this.lbladi.Text = "Tedarikçi Firma:";
            // 
            // btnekle
            // 
            this.btnekle.BackColor = System.Drawing.Color.LightGreen;
            this.btnekle.Location = new System.Drawing.Point(96, 371);
            this.btnekle.Name = "btnekle";
            this.btnekle.Size = new System.Drawing.Size(75, 23);
            this.btnekle.TabIndex = 59;
            this.btnekle.Text = "Ekle";
            this.btnekle.UseVisualStyleBackColor = false;
            this.btnekle.Click += new System.EventHandler(this.btnekle_Click);
            // 
            // btnGeri
            // 
            this.btnGeri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnGeri.Location = new System.Drawing.Point(215, 371);
            this.btnGeri.Name = "btnGeri";
            this.btnGeri.Size = new System.Drawing.Size(75, 23);
            this.btnGeri.TabIndex = 58;
            this.btnGeri.Text = "Geri";
            this.btnGeri.UseVisualStyleBackColor = false;
            this.btnGeri.Click += new System.EventHandler(this.btnGeri_Click);
            // 
            // rbKadin
            // 
            this.rbKadin.AutoSize = true;
            this.rbKadin.Location = new System.Drawing.Point(178, 313);
            this.rbKadin.Name = "rbKadin";
            this.rbKadin.Size = new System.Drawing.Size(55, 19);
            this.rbKadin.TabIndex = 57;
            this.rbKadin.TabStop = true;
            this.rbKadin.Text = "Kadın";
            this.rbKadin.UseVisualStyleBackColor = true;
            // 
            // rbErkek
            // 
            this.rbErkek.AutoSize = true;
            this.rbErkek.Location = new System.Drawing.Point(271, 313);
            this.rbErkek.Name = "rbErkek";
            this.rbErkek.Size = new System.Drawing.Size(53, 19);
            this.rbErkek.TabIndex = 56;
            this.rbErkek.TabStop = true;
            this.rbErkek.Text = "Erkek";
            this.rbErkek.UseVisualStyleBackColor = true;
            // 
            // rbCocuk
            // 
            this.rbCocuk.AutoSize = true;
            this.rbCocuk.Location = new System.Drawing.Point(365, 313);
            this.rbCocuk.Name = "rbCocuk";
            this.rbCocuk.Size = new System.Drawing.Size(59, 19);
            this.rbCocuk.TabIndex = 55;
            this.rbCocuk.TabStop = true;
            this.rbCocuk.Text = "Çocuk";
            this.rbCocuk.UseVisualStyleBackColor = true;
            // 
            // lblkategori
            // 
            this.lblkategori.AutoSize = true;
            this.lblkategori.BackColor = System.Drawing.Color.PeachPuff;
            this.lblkategori.Location = new System.Drawing.Point(65, 317);
            this.lblkategori.Name = "lblkategori";
            this.lblkategori.Size = new System.Drawing.Size(54, 15);
            this.lblkategori.TabIndex = 54;
            this.lblkategori.Text = "Kategori:";
            // 
            // cbmiktar
            // 
            this.cbmiktar.FormattingEnabled = true;
            this.cbmiktar.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbmiktar.Location = new System.Drawing.Point(178, 266);
            this.cbmiktar.Name = "cbmiktar";
            this.cbmiktar.Size = new System.Drawing.Size(100, 23);
            this.cbmiktar.TabIndex = 53;
            this.cbmiktar.Text = "Miktar seçiniz";
            // 
            // txtcins
            // 
            this.txtcins.Location = new System.Drawing.Point(178, 170);
            this.txtcins.Name = "txtcins";
            this.txtcins.Size = new System.Drawing.Size(100, 23);
            this.txtcins.TabIndex = 52;
            // 
            // txtfiyat
            // 
            this.txtfiyat.Location = new System.Drawing.Point(178, 207);
            this.txtfiyat.Name = "txtfiyat";
            this.txtfiyat.Size = new System.Drawing.Size(100, 23);
            this.txtfiyat.TabIndex = 51;
            // 
            // txtadres
            // 
            this.txtadres.Location = new System.Drawing.Point(178, 97);
            this.txtadres.Name = "txtadres";
            this.txtadres.Size = new System.Drawing.Size(100, 23);
            this.txtadres.TabIndex = 50;
            // 
            // txttarih
            // 
            this.txttarih.Location = new System.Drawing.Point(178, 132);
            this.txttarih.Name = "txttarih";
            this.txttarih.Size = new System.Drawing.Size(100, 23);
            this.txttarih.TabIndex = 49;
            // 
            // lblSprsFiyat
            // 
            this.lblSprsFiyat.AutoSize = true;
            this.lblSprsFiyat.BackColor = System.Drawing.Color.PeachPuff;
            this.lblSprsFiyat.Location = new System.Drawing.Point(65, 215);
            this.lblSprsFiyat.Name = "lblSprsFiyat";
            this.lblSprsFiyat.Size = new System.Drawing.Size(65, 15);
            this.lblSprsFiyat.TabIndex = 48;
            this.lblSprsFiyat.Text = "Ürün fiyatı:";
            // 
            // lblSprsmiktar
            // 
            this.lblSprsmiktar.AutoSize = true;
            this.lblSprsmiktar.BackColor = System.Drawing.Color.PeachPuff;
            this.lblSprsmiktar.Location = new System.Drawing.Point(65, 274);
            this.lblSprsmiktar.Name = "lblSprsmiktar";
            this.lblSprsmiktar.Size = new System.Drawing.Size(47, 15);
            this.lblSprsmiktar.TabIndex = 47;
            this.lblSprsmiktar.Text = "Miktarı:";
            // 
            // lblSprsCins
            // 
            this.lblSprsCins.AutoSize = true;
            this.lblSprsCins.BackColor = System.Drawing.Color.PeachPuff;
            this.lblSprsCins.Location = new System.Drawing.Point(65, 173);
            this.lblSprsCins.Name = "lblSprsCins";
            this.lblSprsCins.Size = new System.Drawing.Size(63, 15);
            this.lblSprsCins.TabIndex = 46;
            this.lblSprsCins.Text = "Ürün cinsi:";
            // 
            // lblsprsTarih
            // 
            this.lblsprsTarih.AutoSize = true;
            this.lblsprsTarih.BackColor = System.Drawing.Color.PeachPuff;
            this.lblsprsTarih.Location = new System.Drawing.Point(65, 140);
            this.lblsprsTarih.Name = "lblsprsTarih";
            this.lblsprsTarih.Size = new System.Drawing.Size(35, 15);
            this.lblsprsTarih.TabIndex = 45;
            this.lblsprsTarih.Text = "Tarih:";
            // 
            // lblSprsAdres
            // 
            this.lblSprsAdres.AutoSize = true;
            this.lblSprsAdres.BackColor = System.Drawing.Color.PeachPuff;
            this.lblSprsAdres.Location = new System.Drawing.Point(65, 105);
            this.lblSprsAdres.Name = "lblSprsAdres";
            this.lblSprsAdres.Size = new System.Drawing.Size(95, 15);
            this.lblSprsAdres.TabIndex = 44;
            this.lblSprsAdres.Text = "Tedarikçi Adresi :";
            // 
            // Siparis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(899, 462);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtrunkodu);
            this.Controls.Add(this.lblurunkodu);
            this.Controls.Add(this.txtadi);
            this.Controls.Add(this.lbladi);
            this.Controls.Add(this.btnekle);
            this.Controls.Add(this.btnGeri);
            this.Controls.Add(this.rbKadin);
            this.Controls.Add(this.rbErkek);
            this.Controls.Add(this.rbCocuk);
            this.Controls.Add(this.lblkategori);
            this.Controls.Add(this.cbmiktar);
            this.Controls.Add(this.txtcins);
            this.Controls.Add(this.txtfiyat);
            this.Controls.Add(this.txtadres);
            this.Controls.Add(this.txttarih);
            this.Controls.Add(this.lblSprsFiyat);
            this.Controls.Add(this.lblSprsmiktar);
            this.Controls.Add(this.lblSprsCins);
            this.Controls.Add(this.lblsprsTarih);
            this.Controls.Add(this.lblSprsAdres);
            this.Name = "Siparis";
            this.Text = "Siparis";
            this.Load += new System.EventHandler(this.Siparis_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtrunkodu;
        private System.Windows.Forms.Label lblurunkodu;
        private System.Windows.Forms.TextBox txtadi;
        private System.Windows.Forms.Label lbladi;
        private System.Windows.Forms.Button btnekle;
        private System.Windows.Forms.Button btnGeri;
        private System.Windows.Forms.RadioButton rbKadin;
        private System.Windows.Forms.RadioButton rbErkek;
        private System.Windows.Forms.RadioButton rbCocuk;
        private System.Windows.Forms.Label lblkategori;
        private System.Windows.Forms.ComboBox cbmiktar;
        private System.Windows.Forms.TextBox txtcins;
        private System.Windows.Forms.TextBox txtfiyat;
        private System.Windows.Forms.TextBox txtadres;
        private System.Windows.Forms.TextBox txttarih;
        private System.Windows.Forms.Label lblSprsFiyat;
        private System.Windows.Forms.Label lblSprsmiktar;
        private System.Windows.Forms.Label lblSprsCins;
        private System.Windows.Forms.Label lblsprsTarih;
        private System.Windows.Forms.Label lblSprsAdres;
    }
}