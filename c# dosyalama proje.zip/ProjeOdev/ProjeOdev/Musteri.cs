﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProjeOdev
{
    public partial class Musteri : Form
    {
        public Musteri()
        {
            InitializeComponent();
        }

        private void btnGoster_Click(object sender, EventArgs e)
        {
            StreamReader strreader = File.OpenText(@"c:\Proje\Musteri.txt");
            string metin;
            while ((metin = strreader.ReadLine()) != null)
            {
                listgoster.Items.Add(metin);
            }
            strreader.Close();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            FileStream musteri;
            StreamWriter strMusteri;
            musteri = new FileStream(@"c:\Proje\Musteri.txt", FileMode.Append, FileAccess.Write);
            strMusteri = new StreamWriter(musteri);
            strMusteri.Write(txtAdıSoyadı.Text + "    ");
            strMusteri.Write(txtNumara.Text + "    ");
            strMusteri.Write(txtAdres.Text + "    ");
            strMusteri.WriteLine(txtMail.Text);
            strMusteri.Close();
            musteri.Close();
        }

        private void btngeri_Click(object sender, EventArgs e)
        {
            Form1 formgiris = new Form1();
            formgiris.Show();
            this.Hide();
        }
    }
}
