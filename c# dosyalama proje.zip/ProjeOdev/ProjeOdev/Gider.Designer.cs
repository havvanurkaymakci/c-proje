﻿
namespace ProjeOdev
{
    partial class Gider
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.maas = new System.Windows.Forms.Label();
            this.lblGelir = new System.Windows.Forms.Label();
            this.btngider = new System.Windows.Forms.Button();
            this.listGider = new System.Windows.Forms.ListBox();
            this.btnGeri = new System.Windows.Forms.Button();
            this.btnguncelle = new System.Windows.Forms.Button();
            this.txtAy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtmaas = new System.Windows.Forms.TextBox();
            this.txtdogalgaz = new System.Windows.Forms.TextBox();
            this.lbldogalgaz = new System.Windows.Forms.Label();
            this.txtsu = new System.Windows.Forms.TextBox();
            this.lblSu = new System.Windows.Forms.Label();
            this.txtelektrik = new System.Windows.Forms.TextBox();
            this.lblelektrik = new System.Windows.Forms.Label();
            this.txtKira = new System.Windows.Forms.TextBox();
            this.lblkira = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // maas
            // 
            this.maas.AutoSize = true;
            this.maas.BackColor = System.Drawing.Color.PeachPuff;
            this.maas.Location = new System.Drawing.Point(117, 280);
            this.maas.Name = "maas";
            this.maas.Size = new System.Drawing.Size(82, 15);
            this.maas.TabIndex = 63;
            this.maas.Text = "Çalışan maaş :";
            // 
            // lblGelir
            // 
            this.lblGelir.AutoSize = true;
            this.lblGelir.Location = new System.Drawing.Point(521, 237);
            this.lblGelir.Name = "lblGelir";
            this.lblGelir.Size = new System.Drawing.Size(0, 15);
            this.lblGelir.TabIndex = 62;
            // 
            // btngider
            // 
            this.btngider.BackColor = System.Drawing.Color.LightGreen;
            this.btngider.Location = new System.Drawing.Point(465, 89);
            this.btngider.Name = "btngider";
            this.btngider.Size = new System.Drawing.Size(75, 38);
            this.btngider.TabIndex = 61;
            this.btngider.Text = "Aylık Gider Listesi";
            this.btngider.UseVisualStyleBackColor = false;
            this.btngider.Click += new System.EventHandler(this.btngider_Click);
            // 
            // listGider
            // 
            this.listGider.FormattingEnabled = true;
            this.listGider.ItemHeight = 15;
            this.listGider.Location = new System.Drawing.Point(465, 150);
            this.listGider.Name = "listGider";
            this.listGider.Size = new System.Drawing.Size(253, 169);
            this.listGider.TabIndex = 60;
            // 
            // btnGeri
            // 
            this.btnGeri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnGeri.Location = new System.Drawing.Point(233, 346);
            this.btnGeri.Name = "btnGeri";
            this.btnGeri.Size = new System.Drawing.Size(75, 23);
            this.btnGeri.TabIndex = 59;
            this.btnGeri.Text = "Geri";
            this.btnGeri.UseVisualStyleBackColor = false;
            this.btnGeri.Click += new System.EventHandler(this.btnGeri_Click);
            // 
            // btnguncelle
            // 
            this.btnguncelle.BackColor = System.Drawing.Color.LightGreen;
            this.btnguncelle.Location = new System.Drawing.Point(131, 346);
            this.btnguncelle.Name = "btnguncelle";
            this.btnguncelle.Size = new System.Drawing.Size(75, 23);
            this.btnguncelle.TabIndex = 58;
            this.btnguncelle.Text = "Güncelle";
            this.btnguncelle.UseVisualStyleBackColor = false;
            this.btnguncelle.Click += new System.EventHandler(this.btnguncelle_Click);
            // 
            // txtAy
            // 
            this.txtAy.Location = new System.Drawing.Point(218, 86);
            this.txtAy.Name = "txtAy";
            this.txtAy.Size = new System.Drawing.Size(100, 23);
            this.txtAy.TabIndex = 57;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PeachPuff;
            this.label1.Location = new System.Drawing.Point(117, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 15);
            this.label1.TabIndex = 56;
            this.label1.Text = "Ay giriniz :";
            // 
            // txtmaas
            // 
            this.txtmaas.Location = new System.Drawing.Point(218, 277);
            this.txtmaas.Name = "txtmaas";
            this.txtmaas.Size = new System.Drawing.Size(100, 23);
            this.txtmaas.TabIndex = 55;
            // 
            // txtdogalgaz
            // 
            this.txtdogalgaz.Location = new System.Drawing.Point(218, 241);
            this.txtdogalgaz.Name = "txtdogalgaz";
            this.txtdogalgaz.Size = new System.Drawing.Size(100, 23);
            this.txtdogalgaz.TabIndex = 54;
            // 
            // lbldogalgaz
            // 
            this.lbldogalgaz.AutoSize = true;
            this.lbldogalgaz.BackColor = System.Drawing.Color.PeachPuff;
            this.lbldogalgaz.Location = new System.Drawing.Point(117, 244);
            this.lbldogalgaz.Name = "lbldogalgaz";
            this.lbldogalgaz.Size = new System.Drawing.Size(62, 15);
            this.lbldogalgaz.TabIndex = 53;
            this.lbldogalgaz.Text = "Doğalgaz :";
            // 
            // txtsu
            // 
            this.txtsu.Location = new System.Drawing.Point(218, 203);
            this.txtsu.Name = "txtsu";
            this.txtsu.Size = new System.Drawing.Size(100, 23);
            this.txtsu.TabIndex = 52;
            // 
            // lblSu
            // 
            this.lblSu.AutoSize = true;
            this.lblSu.BackColor = System.Drawing.Color.PeachPuff;
            this.lblSu.Location = new System.Drawing.Point(117, 206);
            this.lblSu.Name = "lblSu";
            this.lblSu.Size = new System.Drawing.Size(26, 15);
            this.lblSu.TabIndex = 51;
            this.lblSu.Text = "Su :";
            // 
            // txtelektrik
            // 
            this.txtelektrik.Location = new System.Drawing.Point(218, 164);
            this.txtelektrik.Name = "txtelektrik";
            this.txtelektrik.Size = new System.Drawing.Size(100, 23);
            this.txtelektrik.TabIndex = 50;
            // 
            // lblelektrik
            // 
            this.lblelektrik.AutoSize = true;
            this.lblelektrik.BackColor = System.Drawing.Color.PeachPuff;
            this.lblelektrik.Location = new System.Drawing.Point(117, 167);
            this.lblelektrik.Name = "lblelektrik";
            this.lblelektrik.Size = new System.Drawing.Size(51, 15);
            this.lblelektrik.TabIndex = 49;
            this.lblelektrik.Text = "Elektrik :";
            // 
            // txtKira
            // 
            this.txtKira.Location = new System.Drawing.Point(218, 127);
            this.txtKira.Name = "txtKira";
            this.txtKira.Size = new System.Drawing.Size(100, 23);
            this.txtKira.TabIndex = 48;
            // 
            // lblkira
            // 
            this.lblkira.AutoSize = true;
            this.lblkira.BackColor = System.Drawing.Color.PeachPuff;
            this.lblkira.Location = new System.Drawing.Point(117, 130);
            this.lblkira.Name = "lblkira";
            this.lblkira.Size = new System.Drawing.Size(33, 15);
            this.lblkira.TabIndex = 47;
            this.lblkira.Text = "Kira :";
            // 
            // Gider
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(835, 454);
            this.Controls.Add(this.maas);
            this.Controls.Add(this.lblGelir);
            this.Controls.Add(this.btngider);
            this.Controls.Add(this.listGider);
            this.Controls.Add(this.btnGeri);
            this.Controls.Add(this.btnguncelle);
            this.Controls.Add(this.txtAy);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtmaas);
            this.Controls.Add(this.txtdogalgaz);
            this.Controls.Add(this.lbldogalgaz);
            this.Controls.Add(this.txtsu);
            this.Controls.Add(this.lblSu);
            this.Controls.Add(this.txtelektrik);
            this.Controls.Add(this.lblelektrik);
            this.Controls.Add(this.txtKira);
            this.Controls.Add(this.lblkira);
            this.Name = "Gider";
            this.Text = "Gider";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label maas;
        private System.Windows.Forms.Label lblGelir;
        private System.Windows.Forms.Button btngider;
        private System.Windows.Forms.ListBox listGider;
        private System.Windows.Forms.Button btnGeri;
        private System.Windows.Forms.Button btnguncelle;
        private System.Windows.Forms.TextBox txtAy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtmaas;
        private System.Windows.Forms.TextBox txtdogalgaz;
        private System.Windows.Forms.Label lbldogalgaz;
        private System.Windows.Forms.TextBox txtsu;
        private System.Windows.Forms.Label lblSu;
        private System.Windows.Forms.TextBox txtelektrik;
        private System.Windows.Forms.Label lblelektrik;
        private System.Windows.Forms.TextBox txtKira;
        private System.Windows.Forms.Label lblkira;
    }
}