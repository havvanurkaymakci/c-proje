﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProjeOdev
{
    public partial class Urun : Form
    {
        public Urun()
        {
            InitializeComponent();
        }

        private void Urun_Load(object sender, EventArgs e)
        {

        }

        private void btnurunekle_Click(object sender, EventArgs e)
        {
            string kategori = "Kadın";
            FileStream urunDepok;
            StreamWriter strurun;
            urunDepok = new FileStream(@"c:\Proje\StokDosyası\Depo.txt", FileMode.Append, FileAccess.Write);
            strurun = new StreamWriter(urunDepok);
            strurun.Write(txturunkodu.Text + "      ");
            strurun.Write(txturunadı.Text + "      ");
            strurun.Write(txturunfiyat.Text + "      ");
            strurun.Write(txtmiktar.Text + "    ");

            if (rbtnkadin.Checked == true)
            {
                strurun.WriteLine(kategori = "Kadın ");
            }
            if (rbtnerkek.Checked == true)
            {
                strurun.WriteLine(kategori = "Erkek ");
            }
            if (rbtncocuk.Checked == true)
            {
                strurun.WriteLine(kategori = "Çocuk ");
            }

            strurun.Close();
            urunDepok.Close();

        }

        private void btnrafekle_Click(object sender, EventArgs e)
        {
            string kategori;
            FileStream urunRaf;
            StreamWriter strUrun;
            urunRaf = new FileStream(@"c:\Proje\StokDosyası\Raf.txt", FileMode.Append, FileAccess.Write);
            strUrun = new StreamWriter(urunRaf);
            strUrun.Write(txturunkodu.Text + "    ");
            strUrun.Write(txturunadı.Text + "    ");
            strUrun.Write(txturunfiyat.Text + "    ");
            strUrun.Write(txtmiktar.Text + "    ");

            if (rbtnkadin.Checked == true)
            {
                strUrun.WriteLine(kategori = "Kadın");
            }
            if (rbtnerkek.Checked == true)
            {
                strUrun.WriteLine(kategori = "Erkek");
            }
            if (rbtncocuk.Checked == true)
            {
                strUrun.WriteLine(kategori = "Çocuk");
            }
            strUrun.Close();
            urunRaf.Close();
        }

        private void btndepo_Click(object sender, EventArgs e)
        {
            StreamReader depoListe;
            StreamReader sRead = File.OpenText(@"c:\Proje\StokDosyası\Depo.txt");
            string metin;
            while ((metin = sRead.ReadLine()) != null)
            {
                Depoliste.Items.Add(metin);
            }
            sRead.Close();
        }

        private void btnraf_Click(object sender, EventArgs e)
        {
            StreamReader rafListe;
            StreamReader sRead = File.OpenText(@"c:\Proje\StokDosyası\Raf.txt");
            string metin;
            while ((metin = sRead.ReadLine()) != null)
            {
                Rafliste.Items.Add(metin);
            }

            sRead.Close();
        }

        private void btngeri_Click(object sender, EventArgs e)
        {
            Form1 formGeri = new Form1();
            formGeri.Show();
            this.Hide();
        }

        private void btnara_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Depoliste.Items.Count; i++)
            {
                if (Depoliste.Items[i].ToString().ToLower().Contains(txtgirilenkod.Text.ToLower()))
                {
                    Depoliste.SetSelected(i, true);
                }
            }
        }

        private void btnal_Click(object sender, EventArgs e)
        {
            int secili = Depoliste.SelectedIndex;
            Depoliste.Items.RemoveAt(secili);

            string dosyayolu = @"c:\Proje\StokDosyası\Depo.txt";
            TextWriter tw = new StreamWriter(dosyayolu);
            tw.Write("");
            tw.Close();

            string[] kayıtdizisi = new string[Depoliste.Items.Count];
            Depoliste.Items.CopyTo(kayıtdizisi, 0);
            System.IO.File.WriteAllLines(dosyayolu, kayıtdizisi);

        }
    }
}
