﻿
namespace ProjeOdev
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnurun = new System.Windows.Forms.Button();
            this.btngider = new System.Windows.Forms.Button();
            this.listtedarik = new System.Windows.Forms.ListBox();
            this.listsiparis = new System.Windows.Forms.ListBox();
            this.gbtedarik = new System.Windows.Forms.GroupBox();
            this.btntedarikci = new System.Windows.Forms.Button();
            this.btnlistele = new System.Windows.Forms.Button();
            this.btntedarik = new System.Windows.Forms.Button();
            this.btnMusteri = new System.Windows.Forms.Button();
            this.gbtedarik.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnurun
            // 
            this.btnurun.BackColor = System.Drawing.Color.PowderBlue;
            this.btnurun.Location = new System.Drawing.Point(316, 43);
            this.btnurun.Name = "btnurun";
            this.btnurun.Size = new System.Drawing.Size(105, 45);
            this.btnurun.TabIndex = 29;
            this.btnurun.Text = "Ürün İşlemleri";
            this.btnurun.UseVisualStyleBackColor = false;
            this.btnurun.Click += new System.EventHandler(this.btnurun_Click);
            // 
            // btngider
            // 
            this.btngider.BackColor = System.Drawing.Color.PowderBlue;
            this.btngider.Location = new System.Drawing.Point(198, 43);
            this.btngider.Name = "btngider";
            this.btngider.Size = new System.Drawing.Size(103, 45);
            this.btngider.TabIndex = 34;
            this.btngider.Text = "Gider İşlemleri";
            this.btngider.UseVisualStyleBackColor = false;
            this.btngider.Click += new System.EventHandler(this.btngider_Click);
            // 
            // listtedarik
            // 
            this.listtedarik.FormattingEnabled = true;
            this.listtedarik.ItemHeight = 15;
            this.listtedarik.Location = new System.Drawing.Point(435, 359);
            this.listtedarik.Name = "listtedarik";
            this.listtedarik.Size = new System.Drawing.Size(279, 49);
            this.listtedarik.TabIndex = 33;
            // 
            // listsiparis
            // 
            this.listsiparis.FormattingEnabled = true;
            this.listsiparis.ItemHeight = 15;
            this.listsiparis.Location = new System.Drawing.Point(435, 294);
            this.listsiparis.Name = "listsiparis";
            this.listsiparis.Size = new System.Drawing.Size(279, 49);
            this.listsiparis.TabIndex = 32;
            // 
            // gbtedarik
            // 
            this.gbtedarik.BackColor = System.Drawing.Color.Transparent;
            this.gbtedarik.Controls.Add(this.btntedarikci);
            this.gbtedarik.Controls.Add(this.btnlistele);
            this.gbtedarik.Controls.Add(this.btntedarik);
            this.gbtedarik.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gbtedarik.Location = new System.Drawing.Point(120, 105);
            this.gbtedarik.Name = "gbtedarik";
            this.gbtedarik.Size = new System.Drawing.Size(266, 126);
            this.gbtedarik.TabIndex = 31;
            this.gbtedarik.TabStop = false;
            this.gbtedarik.Text = "Tedarik İşlemleri";
            // 
            // btntedarikci
            // 
            this.btntedarikci.BackColor = System.Drawing.Color.PowderBlue;
            this.btntedarikci.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btntedarikci.Location = new System.Drawing.Point(6, 66);
            this.btntedarikci.Name = "btntedarikci";
            this.btntedarikci.Size = new System.Drawing.Size(116, 30);
            this.btntedarikci.TabIndex = 20;
            this.btntedarikci.Text = "Tedarikçi Listesi";
            this.btntedarikci.UseVisualStyleBackColor = false;
            this.btntedarikci.Click += new System.EventHandler(this.btntedarikci_Click);
            // 
            // btnlistele
            // 
            this.btnlistele.BackColor = System.Drawing.Color.PowderBlue;
            this.btnlistele.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnlistele.Location = new System.Drawing.Point(141, 35);
            this.btnlistele.Name = "btnlistele";
            this.btnlistele.Size = new System.Drawing.Size(116, 49);
            this.btnlistele.TabIndex = 19;
            this.btnlistele.Text = "Sipariş Edilen Ürünleri Listele\r\n";
            this.btnlistele.UseVisualStyleBackColor = false;
            this.btnlistele.Click += new System.EventHandler(this.btnlistele_Click);
            // 
            // btntedarik
            // 
            this.btntedarik.BackColor = System.Drawing.Color.PowderBlue;
            this.btntedarik.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btntedarik.Location = new System.Drawing.Point(6, 22);
            this.btntedarik.Name = "btntedarik";
            this.btntedarik.Size = new System.Drawing.Size(116, 26);
            this.btntedarik.TabIndex = 6;
            this.btntedarik.Text = "Sipariş Ekle";
            this.btntedarik.UseVisualStyleBackColor = false;
            this.btntedarik.Click += new System.EventHandler(this.btntedarik_Click);
            // 
            // btnMusteri
            // 
            this.btnMusteri.BackColor = System.Drawing.Color.PowderBlue;
            this.btnMusteri.Location = new System.Drawing.Point(87, 43);
            this.btnMusteri.Name = "btnMusteri";
            this.btnMusteri.Size = new System.Drawing.Size(96, 45);
            this.btnMusteri.TabIndex = 30;
            this.btnMusteri.Text = "Müşteri İşlemleri";
            this.btnMusteri.UseVisualStyleBackColor = false;
            this.btnMusteri.Click += new System.EventHandler(this.btnMusteri_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjeOdev.Properties.Resources.cyber_monday_happy_shopping_background_free_vector;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnurun);
            this.Controls.Add(this.btngider);
            this.Controls.Add(this.listtedarik);
            this.Controls.Add(this.listsiparis);
            this.Controls.Add(this.gbtedarik);
            this.Controls.Add(this.btnMusteri);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbtedarik.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnurun;
        private System.Windows.Forms.Button btngider;
        private System.Windows.Forms.ListBox listtedarik;
        private System.Windows.Forms.ListBox listsiparis;
        private System.Windows.Forms.GroupBox gbtedarik;
        private System.Windows.Forms.Button btntedarikci;
        private System.Windows.Forms.Button btnlistele;
        private System.Windows.Forms.Button btntedarik;
        private System.Windows.Forms.Button btnMusteri;
    }
}

