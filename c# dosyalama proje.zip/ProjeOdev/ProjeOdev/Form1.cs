﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProjeOdev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnMusteri_Click(object sender, EventArgs e)
        {
            Musteri musteri = new Musteri();
            musteri.Show();
            this.Hide();
        }

        private void btngider_Click(object sender, EventArgs e)
        {
            Gider gider = new Gider();
            gider.Show();
            this.Hide();
        }

        private void btnurun_Click(object sender, EventArgs e)
        {
            Urun urunform = new Urun();
            urunform.Show();
            this.Hide();
        }

        private void btntedarik_Click(object sender, EventArgs e)
        {
            Siparis siparis = new Siparis();
            siparis.Show();
            this.Hide();
        }

        private void btntedarikci_Click(object sender, EventArgs e)
        {
            StreamReader sRead = File.OpenText(@"c:\Proje\Tedarikci.txt");
            string metin;
            while ((metin = sRead.ReadLine()) != null)
            {
                listtedarik.Items.Add(metin);
            }
            sRead.Close();
        }

        private void btnlistele_Click(object sender, EventArgs e)
        {
            StreamReader sRead = File.OpenText(@"c:\Proje\Siparis.txt");
            string metin;

            while ((metin = sRead.ReadLine()) != null)
            {
                listsiparis.Items.Add(metin);
            }
            sRead.Close();
        }
    }
}
