﻿#include <iostream>
#include <fstream> // dosyalama işlemleri için
#include <string>
#include <locale.h> // Türkçe karakter kütüphanesi
#include <stdio.h>
#include <windows.h>

using namespace std;

int main(int argc, char* argv[]) {
	setlocale(LC_ALL, "Turkish"); // Türkçe karakter kullanımım için


		// Ürün dosyasında tutulacak bilgiler
		string Urun_kodu;
		string Urun_adı;
		string Ureticisi;
		string Temin_suresi;
		string Uretim_tarihi;
		float Fiyat;
		float Fiyat_Ozel;
		float Kdv_oranı;
		int Stok_adedi;
		int Urun_adedi;
		string urunkodu;

		// Cari dosyada tutulacak bilgiler
		double Firma_no;
		string Firma_adi;
		double Firma_telefon;
		string Firma_sorumlusu;
		string Musteri_kategorisi;
		string Adres;

		// sipariş dosyasında tutulacak bilgiler
		//double Firma_no;
		string Siparis_tarihi;
		string Siparis_tutarı;
		string Siparis_listesi_dosyası;
		string Siparisi_alan;

		int secim;


		ofstream siparişDosyasıYaz;
		siparişDosyasıYaz.open("sipariş.txt", ios::app); 

		cout << "\n Firma no : "; cin >> Firma_no;
		cout << "\n Sipariş tarihi :"; cin >> Siparis_tarihi;
		cout << "\n Sipariş tuatarı :"; cin >> Siparis_tutarı;
		cout << "\n Sipariş listesi dosyası :"; cin >> Siparis_listesi_dosyası;
		cout << "\n Sipariş tarihi :"; cin >> Siparis_tarihi;
		cout << "\n Siparişi alan :"; cin >> Siparisi_alan;

		siparişDosyasıYaz << Firma_no << " " << Siparis_tarihi << " " << Siparis_tutarı << " " << Siparis_listesi_dosyası << " " << Siparis_tarihi << " " << Siparisi_alan << "\n";

		siparişDosyasıYaz.close();
		cout << "dosyaya yazım tamamlandı. ";


		ofstream siparisListesiDosyasıYaz;
		siparisListesiDosyasıYaz.open("siparislistesi.txt", ios::app);

		cout << "\n Ürün kodu : "; cin >> Urun_kodu;
		cout << "\n Ürün adedi : "; cin >> Urun_adedi;

		siparisListesiDosyasıYaz << Urun_kodu << " " << Urun_adedi << "\n";

		siparisListesiDosyasıYaz.close();
		cout << "dosyaya yazım tamamlandı. ";

		//Ürün için işlemler
			// 1.Ürün ekleme
			// 2.Ürün arama
			// 3.Ürün listeleme
			// 4.Ürün düzeltme
			// 5.Ürün silme


		char cevap = 'e';

		do {
			cout << " Hangi işemi yapmak istiyorsunuz ? " << endl;  //Kullanıcının yapacağı işlemi seçmesi için
			cout << " 1) Ürün ekleme  " << endl;
			cout << " 2) Ürün arama " << endl;
			cout << " 3) Ürün listeleme " << endl;
			cout << " 4) Ürün düzeltme" << endl;
			cout << " 5) Ürün silme " << endl;
			cin >> secim;

		} while (secim != 1 && secim != 2 && secim != 3 && secim != 4 && secim != 5);  

		if (secim == 1)  // Ürün eklemek için
		{
			cout << "Ürün ekleme" << endl;
			ofstream urunDosyasıYaz;   // dosya açtık
			urunDosyasıYaz.open("urun.txt ", ios::app);
			do 
			{
				// ürün bilgileri
				cout << "\n Ürün kodu : "; cin >> Urun_kodu;
				cout << "\n Ürün adı : "; cin >> Urun_adı;
				cout << "\n Üreticisi : "; cin >> Ureticisi;
				cout << "\n Temin süresi : "; cin >> Temin_suresi;
				cout << "\n Üretim tarihi : "; cin >> Uretim_tarihi;
				cout << "\n Ürünün fiyatı : "; cin >> Fiyat;
				cout << "\n Ürünün özel fiyatı : "; cin >> Fiyat_Ozel;
				cout << "\n KDV oranı : "; cin >> Kdv_oranı;
				cout << "\n Stok adedi : "; cin >> Stok_adedi;

				urunDosyasıYaz << Urun_kodu << " " << Urun_adı << " " << Ureticisi << " " << Temin_suresi << " " << Uretim_tarihi << " " << Fiyat << " " << Fiyat_Ozel << " " << Kdv_oranı << " " << Stok_adedi << "\n";
				cout << "\n Başka ürün eklemek ister misiniz ? (e/h) "; cin >> cevap;

			} while (!(cevap == 'h'));
			urunDosyasıYaz.close();
			cout << "dosyaya yazım tamamlandı. ";

		}

		if (secim == 2)  //Ürün aramak için
		{
			cout << "Ürün arama" << endl;

			cout << " Ürün kodu giriniz:";cin >> Urun_kodu;
			ifstream  urunDosyasıOku("ürün.txt"); //Ürün dosyası açtık
			while (!urunDosyasıOku.eof()) // Ürün dosyasını okumak için;
			{
				urunDosyasıOku >> urunkodu >> Urun_adı >> Ureticisi >> Temin_suresi >> Uretim_tarihi >> Fiyat >> Fiyat_Ozel >> Kdv_oranı >> Stok_adedi; "/n";
				cout << "\n Başka ürün aratmak ister misiniz ? (e/h) "; cin >> cevap;

				if (Urun_kodu == urunkodu)
				{
					cout << "Ürün bilgileri:" << endl;
					cout << "\n Ürün kodu : "; cin >> Urun_kodu;
					cout << "\n Ürün adı : "; cin >> Urun_adı;
					cout << "\n Üreticisi : "; cin >> Ureticisi;
					cout << "\n Temin süresi : "; cin >> Temin_suresi;
					cout << "\n Üretim tarihi : "; cin >> Uretim_tarihi;
					cout << "\n Ürünün fiyatı : "; cin >> Fiyat;
					cout << "\n Ürünün özel fiyatı : "; cin >> Fiyat_Ozel;
					cout << "\n KDV oranı : "; cin >> Kdv_oranı;
					cout << "\n Stok adedi : "; cin >> Stok_adedi;
					Urun_kodu = urunkodu;

				}
				else {
					cout << "Ürün bulunamadı" << endl;
				}

				urunDosyasıOku.close(); // dosyayı kapattık
				
			}
		}

		if (secim == 3) // ürün listelemek için
		{
			cout << "Ürün listeleme" << endl;

			ifstream urunDosyasıOku;
			urunDosyasıOku.open("ürün.txt", ios::app);  

			urunDosyasıOku >> urunkodu >> Urun_adı >> Ureticisi >> Temin_suresi >> Uretim_tarihi >> Fiyat >> Fiyat_Ozel >> Kdv_oranı >> Stok_adedi; "/n";

			cout << " \n Ürün bilgileri \n";
			cout << "\n Ürün kodu : "; cin >> Urun_kodu;
			cout << "\n Ürün adı : "; cin >> Urun_adı;
			cout << "\n Üreticisi : "; cin >> Ureticisi;
			cout << "\n Temin süresi : "; cin >> Temin_suresi;
			cout << "\n Üretim tarihi : "; cin >> Uretim_tarihi;
			cout << "\n Ürünün fiyatı : "; cin >> Fiyat;
			cout << "\n Ürünün özel fiyatı : "; cin >> Fiyat_Ozel;
			cout << "\n KDV oranı : "; cin >> Kdv_oranı;
			cout << "\n Stok adedi : "; cin >> Stok_adedi;

			urunDosyasıOku.close();

		}

		if (secim == 4)  // düzeltme yapmak için
		{
			cout << "Ürün düzeltme" << endl;

			ifstream urunDosyasıOku;
			urunDosyasıOku.open("ürün.txt", ios::app);
			cout << "\n Ürün bilgileri \n";
			cout << " Ürün kodunu giriniz :";
			cin >> Urun_kodu;
			if (Urun_kodu == urunkodu)
			{
				urunDosyasıOku.close();

				ofstream urunDosyasıYaz;
				urunDosyasıYaz.open("ürün.txt", ios::app);

				cout << "\n Ürün kodu : "; cin >> Urun_kodu;
				cout << "\n Ürün adı : "; cin >> Urun_adı;
				cout << "\n Üreticisi : "; cin >> Ureticisi;
				cout << "\n Temin süresi : "; cin >> Temin_suresi;
				cout << "\n Üretim tarihi : "; cin >> Uretim_tarihi;
				cout << "\n Ürünün fiyatı : "; cin >> Fiyat;
				cout << "\n Ürünün özel fiyatı : "; cin >> Fiyat_Ozel;
				cout << "\n KDV oranı : "; cin >> Kdv_oranı;
				cout << "\n Stok adedi : "; cin >> Stok_adedi;

				urunDosyasıYaz.close();
			}
			else
			{
				cout << " Üründe düzeltme yapılamadı." << endl;
			}
		}

		 if (secim == 5)  // Ürün kaydı silmek için
				{
					cout << " Ürün kaydı silme " << endl;
					ifstream urunDosyasıOku;
					urunDosyasıOku.open("urun.txt");
					cout << "Ürün kodunu giriniz:";
					cin >> Urun_kodu;
					if ( Urun_kodu == urunkodu)
					{
						remove("urun.txt");
					}
					else
					{
						cout << "aradığınız ürün  bulunamamıştır." << endl;
					}
				}

			// Müşteri dosyası için işlemler
		     //1.Müşteri ekle
			 //2.Müşteri arama
			//3. Müşteri düzeltme.
			//4. Müşteri silme

		 do {
			 cout << " Hangi işemi yapmak istiyorsunuz ? " << endl;  //Kullanıcının yapacağı işlemi seçmesi için
			 cout << " 1) Müşteri ekleme  " << endl;
			 cout << " 2) müşteri arama " << endl;
			 cout << " 3) Müşteri düzeltme" << endl;
			 cout << " 4) Müşteri silme " << endl;
			 cin >> secim;

		 } while (secim != 1 && secim != 2 && secim != 3 && secim != 4 );

		 if (secim == 1) //Müşteri eklemek için
		 {
			 cout << "Müşteri ekleme" << endl;
			 ofstream musteriDosyasıYaz;   // dosya açtık
			 musteriDosyasıYaz.open("cari.txt ", ios::app);
			 do
			 {
				 //İstenilen bilgiler
				 cout << "\n Firma no : "; cin >> Firma_no;
				 cout << "\n Firma adı : "; cin >> Firma_adi;
				 cout << "\n Firma telefonu :"; cin >> Firma_telefon;
				 cout << "\n Firma sorumlusu : "; cin >> Firma_sorumlusu;
				 cout << "\n Müşteri kategorisi : "; cin >> Musteri_kategorisi;
				 cout << "\n Adres : "; cin >> Adres;

				 musteriDosyasiYaz << Firma_no << " " << Firma_adi << " " << Firma_telefon << " " << Firma_sorumlusu << " " << Musteri_kategorisi << " " << Adres << "\n";

			 } while (!(cevap == 'h'));
			 musteriDosyasiYaz.close();
			 cout << "dosyaya yazım tamamlandı. ";

		 }
	
};
